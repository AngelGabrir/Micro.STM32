import serial
import re
import webbrowser
import PySimpleGUI as sg
import sys

def extract_ip_from_text(text):
    # Utiliza una expresión regular para encontrar la dirección IP en el texto
    ip_pattern = r"\d{1,3}\.\d{1,3}\.\d{1,3}\.\d{1,3}"
    match = re.search(ip_pattern, text)
    if match:
        return match.group()

def open_url_in_browser(url):
    webbrowser.open(url)
    sys.exit()

def main(puerto_serial_port):
    try:
        # Configura la conexión del puerto serial
        puerto_serial = serial.Serial(puerto_serial_port, 115200, timeout=1)
    except serial.SerialException as e:
        sg.PopupError(f"No se pudo abrir el puerto serial {puerto_serial_port}: {e}")
        return

    try:
        while True:
            # Lee la cadena recibida a través del puerto serial (asumiendo que viene en una línea completa)
            cadena_recibida = puerto_serial.readline().strip().decode('utf-8')

            # Extrae la dirección IP de la cadena recibida
            direccion_ip = extract_ip_from_text(cadena_recibida)

            # Verifica si se encontró una dirección IP válida
            if direccion_ip:
                try:
                    # Intenta abrir la dirección IP en el navegador
                    open_url_in_browser(f"http://{direccion_ip}")
                except Exception as e:
                    sg.PopupError(f"Error al abrir la dirección IP {direccion_ip}: {e}")
    except KeyboardInterrupt:
        sg.Popup("Programa detenido por el usuario.")

if __name__ == "__main__":
    # Crea una pequeña interfaz gráfica para ingresar el puerto serial
    layout = [[sg.Text("Ingresa el puerto serial (por ejemplo, COM1):")],
              [sg.InputText(key="puerto")],
              [sg.Button("Aceptar")]]

    window = sg.Window("Ingresar Puerto Serial", layout)

    while True:
        event, values = window.read()
        if event == sg.WINDOW_CLOSED:
            break
        if event == "Aceptar":
            main(values["puerto"])
            break

    window.close()
